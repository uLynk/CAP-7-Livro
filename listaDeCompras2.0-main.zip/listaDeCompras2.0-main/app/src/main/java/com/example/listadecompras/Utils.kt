package com.example.listadecompras

class Utils {
    companion object {
        val produtosGlobal = mutableListOf<Produto>()
    }
}